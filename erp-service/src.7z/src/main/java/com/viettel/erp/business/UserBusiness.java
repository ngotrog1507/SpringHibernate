package com.viettel.erp.business;

public interface UserBusiness {

    long getUserCount();

//    Integer wordCount(String word);

}
