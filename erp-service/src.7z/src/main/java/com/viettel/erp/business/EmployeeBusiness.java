package com.viettel.erp.business;

public interface EmployeeBusiness {

    long count();
}
