package com.viettel.erp.business;

public interface CatConstrDesignItemBusiness {

    long count();
}
