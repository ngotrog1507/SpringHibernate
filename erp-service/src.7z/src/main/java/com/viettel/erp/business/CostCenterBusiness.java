package com.viettel.erp.business;

public interface CostCenterBusiness {

    long count();
//
//    List<CostCenterBO> getAll();
//
//    CostCenterBO getOneById(Long costCenterId);
//
//    Long save(CostCenterBO costCenterBO);
//
//    void delete(CostCenterBO costCenterBO);
//
//    List<CostCenterBO> searchByHql(String hql, List<ConditionBean> conditionBeans);
//
//    List<CostCenterBO> searchByHql(String hql, List<ConditionBean> conditionBeans, int startIdx, int endIdx);
//
//    int countByHql(String hql, List<ConditionBean> conditionBeans);
//
//    List<CostCenterBO> searchByHql(String hql, List<ConditionBean> conditionBeans, List<OrderBean> orderBeans);
//
//    List<CostCenterBO> searchByHql(String hql, List<ConditionBean> conditionBeans, List<OrderBean> orderBeans, int startIdx, int endIdx);
//
//    int executeByHql(String hql, List<ConditionBean> conditionBeans);
//
//    String getSysDate(String pattern);
//
//    Long getNextValSequence(String sequense);
}
