package com.viettel.erp.business;

public interface CatProvinceGroupBusiness {

    long count();
}
