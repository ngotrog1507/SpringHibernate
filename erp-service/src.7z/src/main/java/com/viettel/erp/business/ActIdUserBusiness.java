package com.viettel.erp.business;

public interface ActIdUserBusiness {

    long count();
}
