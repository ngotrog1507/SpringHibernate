package com.viettel.erp.business;

public interface UtilAttachedDocumentsBusiness {

    long count();
}
